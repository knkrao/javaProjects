package spring_mvc_form_nodb;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class EmpController {
	@RequestMapping("/viewData")
	public ModelAndView viewDataMethod()
	{
		List<Emp> empData=new ArrayList<Emp>();
		empData.add(new Emp(1,"kesava"));
		empData.add(new Emp(2,"RAma"));
		empData.add(new Emp(1,"Sri Rama"));
		return new ModelAndView("viewPage","data", empData);
	}
}
