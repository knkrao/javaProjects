package com.indegene;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class helloworldcontroller {
	@RequestMapping("/hello")
	public ModelAndView method1(){
		return new ModelAndView("hellopage","ram","sri rama");
	}
}
